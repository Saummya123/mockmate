import React from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';

const faqs = [
  {
    question: "How does MockMate work?",
    answer: "MockMate uses AI to simulate real interview scenarios. Select your domain, start the interview, and receive instant feedback on your responses."
  },
  {
    question: "Is MockMate free to use?",
    answer: "We offer both free and premium tiers. The free tier includes basic interview simulations, while premium unlocks advanced features and specialized domains."
  },
  {
    question: "Can I practice specific technologies?",
    answer: "Yes! MockMate offers domain-specific interviews covering various technologies and frameworks within each field."
  },
  {
    question: "How realistic are the interviews?",
    answer: "Our AI is trained on real interview data to provide authentic scenarios and follow-up questions similar to actual technical interviews."
  }
];

export const FAQModal = ({ onClose }: { onClose: () => void }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-neon-gray-dark p-8 rounded-lg shadow-xl max-w-2xl w-full mx-4 border border-neon-green/20"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-white">Frequently Asked Questions</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="space-y-6">
          {faqs.map((faq, index) => (
            <div key={index} className="border-b border-gray-700 pb-4 last:border-0">
              <h3 className="text-lg font-medium text-white mb-2">{faq.question}</h3>
              <p className="text-gray-300">{faq.answer}</p>
            </div>
          ))}
        </div>
      </motion.div>
    </motion.div>
  );
};