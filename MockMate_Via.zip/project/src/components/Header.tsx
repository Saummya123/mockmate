import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, HelpCircle, Info, LogIn } from 'lucide-react';
import { LoginModal } from './LoginModal';
import { AboutModal } from './AboutModal';
import { FAQModal } from './FAQModal';

export const Header = () => {
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [isFAQOpen, setIsFAQOpen] = useState(false);

  return (
    <>
      <motion.header 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className="fixed top-0 left-0 right-0 bg-neon-gray-dark/90 backdrop-blur-md z-50 border-b border-neon-green/20"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Menu className="h-6 w-6 text-neon-green" />
            </div>
            
            <nav className="flex items-center space-x-8">
              <motion.button
                whileHover={{ scale: 1.05 }}
                className="flex items-center text-neon-green hover:text-white transition-colors"
                onClick={() => setIsAboutOpen(true)}
              >
                <Info className="h-5 w-5 mr-1" />
                <span>About</span>
              </motion.button>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                className="flex items-center text-neon-green hover:text-white transition-colors"
                onClick={() => setIsFAQOpen(true)}
              >
                <HelpCircle className="h-5 w-5 mr-1" />
                <span>FAQ</span>
              </motion.button>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                className="flex items-center px-4 py-2 rounded-md bg-neon-green text-neon-gray-darker hover:bg-neon-green-dark transition-colors"
                onClick={() => setIsLoginOpen(true)}
              >
                <LogIn className="h-5 w-5 mr-1" />
                <span>Login</span>
              </motion.button>
            </nav>
          </div>
        </div>
      </motion.header>

      <AnimatePresence>
        {isLoginOpen && <LoginModal onClose={() => setIsLoginOpen(false)} />}
        {isAboutOpen && <AboutModal onClose={() => setIsAboutOpen(false)} />}
        {isFAQOpen && <FAQModal onClose={() => setIsFAQOpen(false)} />}
      </AnimatePresence>
    </>
  );
};