import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Upload, ArrowRight, Loader2 } from 'lucide-react';
import { useStore } from '../store/useStore';

export const Onboarding = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    jobRole: '',
    resume: null as File | null,
  });
  const [isUploading, setIsUploading] = useState(false);
  const setUser = useStore((state) => state.setUser);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFormData(prev => ({ ...prev, resume: e.target.files![0] }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (step < 3) {
      setStep(step + 1);
      return;
    }

    // In a real app, you would upload the resume to a server here
    setIsUploading(true);
    try {
      // Simulate file upload
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      setUser({
        isAuthenticated: true,
        name: formData.name,
        jobRole: formData.jobRole,
        resumeUrl: formData.resume ? URL.createObjectURL(formData.resume) : undefined,
      });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-md mx-auto p-6 bg-cyber-gray-dark rounded-lg shadow-lg border border-cyber-purple/20"
    >
      <div className="mb-8">
        <div className="flex justify-between mb-4">
          {[1, 2, 3].map((i) => (
            <div
              key={i}
              className={`w-24 h-1 rounded ${
                i <= step ? 'bg-cyber-purple' : 'bg-cyber-gray-light'
              }`}
            />
          ))}
        </div>
        <h2 className="text-2xl font-bold text-white">
          {step === 1 && "What's your name?"}
          {step === 2 && 'What role are you interviewing for?'}
          {step === 3 && 'Upload your resume'}
        </h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <AnimatedStep show={step === 1}>
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
            placeholder="Enter your full name"
            className="w-full p-3 bg-cyber-gray-light text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-cyber-purple/50"
            required={step === 1}
          />
        </AnimatedStep>

        <AnimatedStep show={step === 2}>
          <input
            type="text"
            value={formData.jobRole}
            onChange={(e) => setFormData(prev => ({ ...prev, jobRole: e.target.value }))}
            placeholder="e.g., Frontend Developer"
            className="w-full p-3 bg-cyber-gray-light text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-cyber-purple/50"
            required={step === 2}
          />
        </AnimatedStep>

        <AnimatedStep show={step === 3}>
          <label className="block w-full p-4 bg-cyber-gray-light text-white rounded-lg border-2 border-dashed border-cyber-purple/50 cursor-pointer hover:bg-cyber-gray-darker transition-colors">
            <input
              type="file"
              onChange={handleFileChange}
              className="hidden"
              accept=".pdf,.doc,.docx"
            />
            <div className="flex flex-col items-center space-y-2">
              <Upload className="h-8 w-8 text-cyber-purple" />
              <span className="text-sm text-gray-400">
                {formData.resume ? formData.resume.name : 'Upload your resume (PDF, DOC)'}
              </span>
            </div>
          </label>
        </AnimatedStep>

        <button
          type="submit"
          disabled={isUploading}
          className="w-full flex items-center justify-center space-x-2 p-3 bg-cyber-purple text-white rounded-lg hover:bg-cyber-purple-dark disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {isUploading ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin" />
              <span>Processing...</span>
            </>
          ) : (
            <>
              <span>{step === 3 ? 'Complete Setup' : 'Continue'}</span>
              <ArrowRight className="h-5 w-5" />
            </>
          )}
        </button>
      </form>
    </motion.div>
  );
};

const AnimatedStep = ({ show, children }: { show: boolean; children: React.ReactNode }) => (
  <motion.div
    initial={{ opacity: 0, x: 20 }}
    animate={{ opacity: show ? 1 : 0, x: show ? 0 : 20 }}
    exit={{ opacity: 0, x: -20 }}
    className={show ? 'block' : 'hidden'}
  >
    {children}
  </motion.div>
);