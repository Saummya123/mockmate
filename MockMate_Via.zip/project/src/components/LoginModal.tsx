import React from 'react';
import { motion } from 'framer-motion';
import { X, Mail } from 'lucide-react';

export const LoginModal = ({ onClose }: { onClose: () => void }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-neon-gray-dark p-8 rounded-lg shadow-xl max-w-md w-full mx-4 border border-neon-green/20"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-white">Login to MockMate</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="space-y-4">
          <button className="w-full flex items-center justify-center gap-2 bg-white text-gray-800 p-3 rounded-md hover:bg-gray-100 transition-colors">
            <Mail className="h-5 w-5" />
            Continue with Google
          </button>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-600"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-neon-gray-dark text-gray-400">Or continue with</span>
            </div>
          </div>

          <form className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Email</label>
              <input
                type="email"
                className="w-full p-3 rounded-md bg-neon-gray-darker border border-neon-green/20 text-white focus:outline-none focus:border-neon-green"
                placeholder="Enter your email"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Password</label>
              <input
                type="password"
                className="w-full p-3 rounded-md bg-neon-gray-darker border border-neon-green/20 text-white focus:outline-none focus:border-neon-green"
                placeholder="Enter your password"
              />
            </div>
            <button
              type="submit"
              className="w-full bg-neon-green text-neon-gray-darker p-3 rounded-md hover:bg-neon-green-dark transition-colors font-medium"
            >
              Sign in
            </button>
          </form>
        </div>
      </motion.div>
    </motion.div>
  );
};