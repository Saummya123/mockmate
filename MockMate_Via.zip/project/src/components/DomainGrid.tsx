import React from 'react';
import { motion } from 'framer-motion';
import { Code2, Database, Globe, Terminal, Cpu, Server, LineChart, Shield, Smartphone, Cloud } from 'lucide-react';
import { useStore } from '../store/useStore';
import type { Domain } from '../types';

const domains: Domain[] = [
  { id: 'web', name: 'Web Development', icon: 'Globe', description: 'Frontend and backend web technologies' },
  { id: 'data', name: 'Data Analysis', icon: 'LineChart', description: 'Data processing and visualization' },
  { id: 'cloud', name: 'Cloud Computing', icon: 'Cloud', description: 'Cloud platforms and services' },
  { id: 'mobile', name: 'Mobile Development', icon: 'Smartphone', description: 'iOS and Android development' },
  { id: 'security', name: 'Cybersecurity', icon: 'Shield', description: 'Security and penetration testing' },
  { id: 'devops', name: 'DevOps', icon: 'Server', description: 'CI/CD and infrastructure' },
  { id: 'ai', name: 'AI & ML', icon: 'Cpu', description: 'Machine learning and AI concepts' },
  { id: 'backend', name: 'Backend Development', icon: 'Terminal', description: 'Server-side programming' },
  { id: 'database', name: 'Database', icon: 'Database', description: 'Database design and management' },
  { id: 'algorithms', name: 'Algorithms', icon: 'Code2', description: 'DSA and problem solving' },
];

const iconComponents = {
  Globe, LineChart, Cloud, Smartphone, Shield, Server, Cpu, Terminal, Database, Code2
};

export const DomainGrid = () => {
  const setSelectedDomain = useStore((state) => state.setSelectedDomain);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {domains.map((domain) => {
        const Icon = iconComponents[domain.icon as keyof typeof iconComponents];
        
        return (
          <motion.div
            key={domain.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="bg-white rounded-xl shadow-sm hover:shadow-md transition-all p-6 cursor-pointer border border-gray-100"
            onClick={() => setSelectedDomain(domain)}
          >
            <div className="flex items-start space-x-4">
              <div className="p-3 bg-gradient-to-br from-purple-100 to-blue-100 rounded-lg">
                <Icon className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <h3 className="font-semibold text-lg text-gray-900">{domain.name}</h3>
                <p className="text-gray-600 text-sm mt-1">{domain.description}</p>
              </div>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
};