import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, Send, StopCircle, ArrowRight, RotateCcw, AlertCircle } from 'lucide-react';
import { useStore } from '../store/useStore';
import { fetchQuestions } from '../services/questionService';

export const InterviewInterface = () => {
  const [userInput, setUserInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  
  const {
    selectedDomain,
    currentQuestions,
    currentQuestionIndex,
    isLoading,
    error,
    setQuestions,
    nextQuestion,
    resetInterview,
    setLoading,
    setError
  } = useStore();

  useEffect(() => {
    const loadQuestions = async () => {
      if (selectedDomain) {
        try {
          setLoading(true);
          setError(null);
          const questions = await fetchQuestions(selectedDomain.id);
          
          if (questions.length === 0) {
            throw new Error('No questions available for this domain');
          }
          
          setQuestions(questions);
        } catch (err) {
          setError(err instanceof Error ? err.message : 'Failed to load questions');
        } finally {
          setLoading(false);
        }
      }
    };
    
    loadQuestions();
  }, [selectedDomain, setQuestions, setLoading, setError]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (userInput.trim()) {
      // Simulate AI feedback
      setFeedback('Your answer shows good understanding. Consider elaborating on performance implications.');
      setUserInput('');
    }
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
  };

  const currentQuestion = currentQuestions[currentQuestionIndex];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-cyber-purple"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-center">
        <AlertCircle className="h-12 w-12 text-red-500 mb-4" />
        <p className="text-red-500 mb-4">{error}</p>
        <button
          onClick={resetInterview}
          className="px-4 py-2 bg-cyber-purple text-white rounded-lg hover:bg-cyber-purple-dark transition-colors"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto p-6 bg-cyber-gray-dark rounded-lg shadow-lg border border-cyber-purple/20"
    >
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-cyber-purple mb-2">
            {selectedDomain?.name} Interview
          </h2>
          <p className="text-gray-400">
            Question {currentQuestionIndex + 1} of {currentQuestions.length}
          </p>
        </div>
        <button
          onClick={resetInterview}
          className="p-2 rounded-full bg-cyber-gray-light hover:bg-cyber-gray-darker transition-colors"
        >
          <RotateCcw className="h-5 w-5 text-cyber-purple" />
        </button>
      </div>

      <AnimatePresence mode="wait">
        {currentQuestion && (
          <motion.div
            key={currentQuestionIndex}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6 mb-8"
          >
            <div className="bg-cyber-gray-light p-4 rounded-lg">
              <p className="text-white text-lg mb-4">{currentQuestion.text}</p>
              {currentQuestion.followUp && currentQuestion.followUp.length > 0 && (
                <div className="mt-4 text-sm text-gray-400">
                  <p className="font-medium mb-2">Consider these aspects:</p>
                  <ul className="list-disc list-inside space-y-1">
                    {currentQuestion.followUp.map((q, i) => (
                      <li key={i}>{q}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {feedback && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-cyber-purple/10 border border-cyber-purple/20 p-4 rounded-lg"
              >
                <p className="text-cyber-purple">{feedback}</p>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="relative">
          <textarea
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            className="w-full p-4 bg-cyber-gray-light text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-cyber-purple/50 resize-none"
            placeholder="Type your response..."
            rows={4}
          />
          <div className="absolute bottom-4 right-4 flex space-x-2">
            <button
              type="button"
              onClick={toggleRecording}
              className={`p-2 rounded-full transition-colors ${
                isRecording
                  ? 'bg-red-500 hover:bg-red-600'
                  : 'bg-cyber-purple hover:bg-cyber-purple-dark'
              }`}
            >
              {isRecording ? (
                <StopCircle className="h-5 w-5 text-white" />
              ) : (
                <Mic className="h-5 w-5 text-white" />
              )}
            </button>
            <button
              type="submit"
              disabled={!userInput.trim()}
              className="p-2 rounded-full bg-cyber-purple hover:bg-cyber-purple-dark disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Send className="h-5 w-5 text-white" />
            </button>
          </div>
        </div>
      </form>

      <div className="mt-6 flex justify-end">
        <button
          onClick={nextQuestion}
          disabled={currentQuestionIndex === currentQuestions.length - 1}
          className="flex items-center space-x-2 px-4 py-2 bg-cyber-purple text-white rounded-lg hover:bg-cyber-purple-dark disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          <span>Next Question</span>
          <ArrowRight className="h-5 w-5" />
        </button>
      </div>
    </motion.div>
  );
};