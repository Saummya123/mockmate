import React from 'react';
import { motion } from 'framer-motion';
import { X } from 'lucide-react';

export const AboutModal = ({ onClose }: { onClose: () => void }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-neon-gray-dark p-8 rounded-lg shadow-xl max-w-2xl w-full mx-4 border border-neon-green/20"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-white">About MockMate</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="prose prose-invert">
          <p className="text-gray-300 leading-relaxed">
            MockMate is your AI-powered interview preparation companion, designed to help you excel in technical interviews across various domains. Our platform simulates realistic interview scenarios, providing personalized feedback and adaptive learning experiences.
          </p>
          
          <h3 className="text-xl font-semibold text-white mt-6 mb-3">Key Features</h3>
          <ul className="space-y-2 text-gray-300">
            <li>• Real-time AI interview simulations</li>
            <li>• Comprehensive feedback and performance analysis</li>
            <li>• Domain-specific question banks</li>
            <li>• Voice interaction capabilities</li>
            <li>• Progress tracking and improvement metrics</li>
          </ul>

          <p className="text-gray-300 mt-6">
            Whether you're preparing for your first technical interview or looking to switch roles, MockMate provides the tools and practice you need to succeed.
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
};