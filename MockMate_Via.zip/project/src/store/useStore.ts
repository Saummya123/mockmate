import { create } from 'zustand';
import type { User, Domain, Question } from '../types';

interface InterviewState {
  user: User;
  selectedDomain: Domain | null;
  currentQuestions: Question[];
  currentQuestionIndex: number;
  isLoading: boolean;
  error: string | null;
}

interface InterviewActions {
  setUser: (user: User) => void;
  setSelectedDomain: (domain: Domain | null) => void;
  setQuestions: (questions: Question[]) => void;
  nextQuestion: () => void;
  resetInterview: () => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
}

type Store = InterviewState & InterviewActions;

const initialState: InterviewState = {
  user: { isAuthenticated: false },
  selectedDomain: null,
  currentQuestions: [],
  currentQuestionIndex: 0,
  isLoading: false,
  error: null,
};

export const useStore = create<Store>((set) => ({
  ...initialState,
  setUser: (user) => set({ user }),
  setSelectedDomain: (domain) => set({ selectedDomain: domain, currentQuestions: [], currentQuestionIndex: 0, error: null }),
  setQuestions: (questions) => set({ currentQuestions: questions, currentQuestionIndex: 0, error: null }),
  nextQuestion: () => set((state) => ({
    currentQuestionIndex: Math.min(state.currentQuestionIndex + 1, state.currentQuestions.length - 1)
  })),
  resetInterview: () => set((state) => ({
    ...initialState,
    user: state.user // Preserve user state
  })),
  setLoading: (loading) => set({ isLoading: loading }),
  setError: (error) => set({ error }),
}));