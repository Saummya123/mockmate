import axios from 'axios';
import type { Question } from '../types';

// Domain-specific interview questions
const domainQuestions: Record<string, Question[]> = {
  'web': [
    {
      id: 'web-1',
      text: 'Explain the difference between client-side and server-side rendering. When would you use each?',
      domain: 'web',
      difficulty: 'intermediate',
      followUp: [
        'How does this affect SEO?',
        'What are the performance implications?',
        'How would you handle authentication in each approach?'
      ]
    },
    {
      id: 'web-2',
      text: 'Describe how you would implement a secure authentication system for a web application.',
      domain: 'web',
      difficulty: 'advanced',
      followUp: [
        'How would you handle password storage?',
        'What measures would you take against XSS and CSRF?',
        'How would you implement refresh tokens?'
      ]
    }
  ],
  'data': [
    {
      id: 'data-1',
      text: 'Explain the differences between SQL and NoSQL databases. When would you choose one over the other?',
      domain: 'data',
      difficulty: 'intermediate',
      followUp: [
        'How do you handle scalability in each?',
        'What about data consistency?',
        'Can you give examples of use cases for each?'
      ]
    }
  ],
  'algorithms': [
    {
      id: 'algo-1',
      text: 'Explain how you would implement a system to detect duplicate files in a large file system efficiently.',
      domain: 'algorithms',
      difficulty: 'advanced',
      followUp: [
        'How would you handle very large files?',
        'What about memory constraints?',
        'How would you parallelize this solution?'
      ]
    }
  ]
  // Add more domains and questions as needed
};

export const fetchQuestions = async (domain: string): Promise<Question[]> => {
  try {
    // First try to get domain-specific questions
    const specificQuestions = domainQuestions[domain] || [];
    
    if (specificQuestions.length > 0) {
      return specificQuestions;
    }

    // Fallback to OpenTDB for general knowledge questions
    const response = await axios.get(`${BASE_URL}?amount=10&category=${mapDomainToCategory(domain)}&type=multiple`);
    
    if (!response.data?.results) {
      throw new Error('No questions available');
    }

    return response.data.results.map((q: any) => ({
      id: Math.random().toString(36).substring(2, 11),
      text: decodeHTMLEntities(q.question),
      domain,
      difficulty: mapDifficulty(q.difficulty),
      followUp: getFollowUpQuestions(domain),
      correctAnswer: decodeHTMLEntities(q.correct_answer),
      incorrectAnswers: q.incorrect_answers.map(decodeHTMLEntities),
    }));
  } catch (error) {
    console.error('Error fetching questions:', error);
    return getDummyQuestions(domain);
  }
};

// Rest of the helper functions remain the same
const BASE_URL = 'https://opentdb.com/api.php';
const mapDifficulty = (difficulty: string): 'beginner' | 'intermediate' | 'advanced' => {
  const difficultyMap: Record<string, 'beginner' | 'intermediate' | 'advanced'> = {
    'easy': 'beginner',
    'medium': 'intermediate',
    'hard': 'advanced'
  };
  return difficultyMap[difficulty] || 'intermediate';
};

const decodeHTMLEntities = (text: string): string => {
  const textarea = document.createElement('textarea');
  textarea.innerHTML = text;
  return textarea.value;
};

// ... (rest of the existing helper functions remain unchanged)