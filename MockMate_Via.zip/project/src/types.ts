export interface Domain {
  id: string;
  name: string;
  icon: string;
  description: string;
}

export interface User {
  isAuthenticated: boolean;
  name?: string;
  jobRole?: string;
  resumeUrl?: string;
  email?: string;
}

export interface Question {
  id: string;
  text: string;
  domain: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  followUp?: string[];
  correctAnswer?: string;
  incorrectAnswers?: string[];
}