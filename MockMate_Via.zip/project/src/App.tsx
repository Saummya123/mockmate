import React from 'react';
import { motion } from 'framer-motion';
import { Header } from './components/Header';
import { CubeScene } from './components/CubeScene';
import { DomainGrid } from './components/DomainGrid';
import { InterviewInterface } from './components/InterviewInterface';
import { Onboarding } from './components/Onboarding';
import { useStore } from './store/useStore';

function App() {
  const { selectedDomain, user } = useStore();

  return (
    <div className="min-h-screen bg-cyber-black text-white overflow-hidden">
      <Header />
      
      <main className="relative pt-24 pb-12">
        {/* Background Gradient Effects */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 -left-1/4 w-96 h-96 bg-cyber-purple/20 rounded-full filter blur-[100px] animate-pulse-slow" />
          <div className="absolute bottom-1/4 -right-1/4 w-96 h-96 bg-cyber-purple/20 rounded-full filter blur-[100px] animate-pulse-slow delay-1000" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          {!user.isAuthenticated ? (
            <>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center mb-16"
              >
                <h1 className="text-6xl font-bold mb-6 tracking-tighter">
                  <motion.span
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 }}
                    className="text-cyber-purple animate-glow"
                  >
                    Mock
                  </motion.span>
                  <motion.span
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4 }}
                  >
                    Mate
                  </motion.span>
                </h1>
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.6 }}
                  className="text-xl text-gray-400 max-w-2xl mx-auto"
                >
                  Your AI-powered interview companion. Practice with realistic scenarios and get instant feedback.
                </motion.p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.8 }}
                className="relative z-10"
              >
                <CubeScene />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1 }}
                className="mt-16"
              >
                <Onboarding />
              </motion.div>
            </>
          ) : selectedDomain ? (
            <InterviewInterface />
          ) : (
            <>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center mb-8"
              >
                <h2 className="text-3xl font-bold mb-2">Welcome, {user.name}!</h2>
                <p className="text-gray-400">Select a domain to begin your interview preparation</p>
              </motion.div>
              <DomainGrid />
            </>
          )}
        </div>
      </main>
    </div>
  );
}

export default App;